from databases.db import DB

# DB.add_user(
#     first_name="Петр", last_name="Петрович", age=15, gender="man", email="asd19998@gmail.com"
# )

# DB.delete_user(1)

# DB.update_user(2, "Саня", "Запупкин")

# DB.search_user("Саня", "Запупкин")

# DB.add_user_friends(2, 5)

# DB.add_user_post(5, "Pulvinar faucibus. Dictumst. Dolor sapien quis, ornare adipiscing urna velit et mattis vel consectet")

# DB.get_date_user(2)

# DB.get_friends_user(2)

# DB.get_user_post(2)
